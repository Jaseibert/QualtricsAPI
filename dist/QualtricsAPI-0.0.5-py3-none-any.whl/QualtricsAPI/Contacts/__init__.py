# __init__.py
from .mailinglists import *
from .xmdirectory import *

__all__ = ['mailinglists', 'xmdirectory']
