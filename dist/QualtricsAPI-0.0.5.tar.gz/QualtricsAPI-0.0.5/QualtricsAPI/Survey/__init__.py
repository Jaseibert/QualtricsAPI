# __init__.py
from .responses import *

__all__ = ['responses']
